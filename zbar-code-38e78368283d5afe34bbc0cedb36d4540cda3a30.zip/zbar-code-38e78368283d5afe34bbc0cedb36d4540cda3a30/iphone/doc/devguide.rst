***********************
   Developer's Guide
***********************

.. toctree::
   :maxdepth: 2

   camera
   picker
   custom
   optimizing
   compat
   licensing
